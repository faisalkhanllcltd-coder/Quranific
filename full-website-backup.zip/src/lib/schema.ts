// src/lib/schema.ts
import { z } from 'zod';

export const signupSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters').max(100),
  email: z.email({ error: 'Please enter a valid email address' }).toLowerCase().trim(),
  whatsapp: z
    .string()
    .min(7, 'WhatsApp number too short')
    .regex(/^\+?[1-9]\d{6,14}$/, 'Must be a valid international phone number'),
  country: z.string().min(2, 'Country is required'),
  source: z.string().default('organic'),
  honeypot: z.string().max(0, 'Bot detected').optional(),
  // B-2 FIX: Turnstile token always required.
  turnstileToken: z.string().min(1, 'Bot check required: please complete the security check.'),
  // ── Funnel calculator context (all optional — not all paths provide them) ──
  enrollType: z.string().optional(),
  duration: z.string().optional(),
  sessions: z.string().optional(),
  currency: z.string().optional(),
  billing: z.string().optional(),
  price: z.string().optional(),
  course: z.string().optional(),
  note: z.string().max(500, 'Note must be 500 characters or less').optional(),
  age: z.string().optional(),
  level: z.string().optional(),
  // ── Ad attribution (all optional) ─────────────────────────────────────────
  fbclid: z.string().optional(),
  gclid: z.string().optional(),
  ttclid: z.string().optional(),
  utm_source: z.string().optional(),
  utm_campaign: z.string().optional(),
  utm_medium: z.string().optional(),
  utm_content: z.string().optional(),
});

export const completeSchema = z.object({
  course: z.string().min(1, 'Please select a course'),
  gender: z.enum(['Male', 'Female'], { error: 'Please select student gender' }),
  teacherGender: z.enum(['Male Teacher', 'Female Teacher', 'No Preference'], {
    error: 'Please select teacher preference',
  }),
  level: z.enum(['Beginner', 'Intermediate', 'Advanced'], {
    error: 'Please select a level',
  }),
  days: z.string().min(1, 'Please select days per week'),
  schedule: z.string().min(1, 'Please select preferred time'),
  // Step 2 extended fields (pre-filled from calculator, editable by user)
  duration: z.string().optional(),
  sessions: z.string().optional(),
  note: z.string().optional(),
  // B-4 FIX: sessionToken removed entirely from completeSchema.
  // The JWT session is now delivered as an HttpOnly cookie ('q_session') and read
  // by complete.ts from the request Cookie header — not from the form body.
});
